Two ways to run the game. This only needs to be done once.

Method A: Open using open.sh (Recommended)
 1. Open Terminal.app or equivalent
 2. Navigate to the directory containing the game
 3. Run sh open.sh

Method B: Open using Finder (May not work)
 1. Double-click game and close the dialogue box
 2. Repeat step 1 at least one more time
 3. Right-click game and click "Open"
